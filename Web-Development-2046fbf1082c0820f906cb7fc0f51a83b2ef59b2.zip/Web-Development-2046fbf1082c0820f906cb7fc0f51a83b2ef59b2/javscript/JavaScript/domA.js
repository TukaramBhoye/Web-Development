function tuka(){
    let a = 12; 
    let b = 23; 
    let c = a + b; 
}
console.log(tuka); 